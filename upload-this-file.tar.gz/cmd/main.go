package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {
	// Print prompt on the same line
	fmt.Print("Please enter your name: ")

	// Create a scanner to read input
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()

	// Get the input and trim whitespace
	name := strings.TrimSpace(scanner.Text())

	// Print greeting
	fmt.Printf("Hello, %s!\n", name)
}
